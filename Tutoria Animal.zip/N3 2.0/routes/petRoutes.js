const express = require('express');
const router = express.Router();
const petController = require('../controllers/petController');

// rota para adicionar um novo pet
router.post('/pets', petController.adicionarPet);
// rota para listar todos os pets
router.get('/pets', petController.listarPets);
// rota para atualizar informações de um pet específico
router.put('/pets/:codigo_pet', petController.atualizarPet);
// rota para excluir um pet específico
router.delete('/pets/:codigo_pet', petController.excluirPet);
// rota para buscar todos os pets de um tutor específico pelo CPF
router.get('/pets/tutor/:cpf_tutor', petController.buscarPetsPorTutor);
//rota para buscar todos os pets de uma altura específica pelo ID da altura
router.get('/pets/altura/:altura_id', petController.buscarPetsPorAltura);

module.exports = router;
