const express = require('express');
const router = express.Router();
const tutorController = require('../controllers/tutorController');
const { verifyToken, generateToken } = require('../middleware/auth');


router.post('/tutores', tutorController.adicionarTutor); //rota para adicionar um novo tutor
router.get('/tutores', tutorController.listarTutores); //rota para listar todos os tutores
router.get('/tutores/:cpf', tutorController.buscarTutorPorCpf); //rota para buscar um tutor por CPF
router.put('/tutores/:cpf', tutorController.atualizarTutor); //rota para atualizar informações de um tutor
router.delete('/tutores/:cpf', tutorController.excluirTutor); //rta para excluir um tutor

//rota de login não protegida pelo verifyToken
router.post('/login', (req, res) => {
    const { cpf, senha } = req.body;
    if (cpf === '12345678900' && senha === '123') { //exemplo de autenticação estática
        const token = generateToken({ cpf });
        return res.json({ message: 'Login realizado com sucesso!', token });
    } else {
        return res.status(401).json({ message: 'CPF ou senha inválidos!' });
    }
});

// Rota protegida por JWT
router.get('/tutores-protegido', verifyToken, (req, res) => {
    res.json({ message: 'Rota protegida por JWT.' });
});

module.exports = router;
