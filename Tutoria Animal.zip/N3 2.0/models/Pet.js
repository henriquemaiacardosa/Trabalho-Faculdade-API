const db = require('../config/db');

class Pet {
    // aqui definimos um método estático para criar um novo pet no banco de dados
    static create(nome_pet, genero_pet, altura_cm, cpf_tutor, callback) {
        let altura_id;
        
        // verificamos a altura do pet para determinar seu id
        if (altura_cm <= 15) {
            altura_id = 1; // Se for menor ou igual a 15 cm = pequeno
        } else if (altura_cm > 15 && altura_cm < 45) {
            altura_id = 2; // se estiver entre 15 cm e 45 cm = médio
        } else {
            altura_id = 3; // + de 45 cm é grande
        }

        // Realizamos a inserção dos dados do pet na tabela do banco de dados
        db.query(
            'INSERT INTO pet (nome_pet, genero_pet, altura_cm, altura_id, cpf_tutor) VALUES (?, ?, ?, ?, ?)',
            [nome_pet, genero_pet, altura_cm, altura_id, cpf_tutor],
            callback
        );
    }

    // aqui temos um método estático para buscar todos os pets cadastrados no banco de dados
    static findAll(callback) {
        db.query('SELECT * FROM pet', callback);
    }

    // este método estático permite buscar pets associados a um tutor específico usando seu CPF
    static findByTutor(cpf_tutor, callback) {
        db.query('SELECT * FROM pet WHERE cpf_tutor = ?', [cpf_tutor], callback);
    }

    // este metodo estático busca pets com base na altura categorizada (pequeno, médio, grande)
    static findByAltura(altura_id, callback) {
        db.query('SELECT * FROM pet WHERE altura_id = ?', [altura_id], callback);
    }

    // aqui implementamos um método estático para atualizar informações de um pet no banco de dados
    static update(codigo_pet, nome_pet, genero_pet, altura_cm, cpf_tutor, callback) {
        let altura_id;
        
        // verificamos novamente a altura para definir o pet atualizado
        if (altura_cm <= 15) {
            altura_id = 1; // se for menor ou igual a 15 cm, é pequeno
        } else if (altura_cm > 15 && altura_cm < 45) {
            altura_id = 2; // entre 15 cm e 45 cm, é médio
        } else {
            altura_id = 3; // acima de 45 cm, é grande
        }

        // executamos a atualização dos dados do pet no banco de dados
        db.query(
            'UPDATE pet SET nome_pet=?, genero_pet=?, altura_cm=?, altura_id=?, cpf_tutor=? WHERE codigo_pet=?',
            [nome_pet, genero_pet, altura_cm, altura_id, cpf_tutor, codigo_pet],
            callback
        );
    }

    // aqui o método estático é utilizado para excluir um pet do banco de dados com base no seu código único
    static delete(codigo_pet, callback) {
        db.query('DELETE FROM pet WHERE codigo_pet=?', [codigo_pet], callback);
    }
}

module.exports = Pet;
