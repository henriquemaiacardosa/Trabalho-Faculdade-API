const db = require('../config/db');

class Tutor {
    // aqui tem um método estático para adicionar um novo tutor no banco de dados
    static create(cpf, nome, email, callback) {
        db.query(
            'INSERT INTO tutor (cpf, nome, email) VALUES (?, ?, ?)',
            [cpf, nome, email],
            callback
        );
    }

    //  método estático busca e retorna todos os tutores cadastrados no banco de dados
    static findAll(callback) {
        db.query('SELECT * FROM tutor', callback);
    }

    // método estático para buscar um tutor específico pelo CPF
    static findByCpf(cpf, callback) {
        db.query('SELECT * FROM tutor WHERE cpf = ?', [cpf], callback);
    }

    // aqui o método estático atualiza as informações de um tutor no banco de dados
    static update(cpf, nome, email, callback) {
        db.query(
            'UPDATE tutor SET nome=?, email=? WHERE cpf=?',
            [nome, email, cpf],
            callback
        );
    }

    // aqui entao o método estático exclui um tutor do banco de dados com base no CPF fornecido
    static delete(cpf, callback) {
        db.query('DELETE FROM tutor WHERE cpf=?', [cpf], callback);
    }
}

module.exports = Tutor;
