const express = require('express');
const bodyParser = require('body-parser');
const tutorRoutes = require('./routes/tutorRoutes');
const petRoutes = require('./routes/petRoutes');

const app = express();
const port = 3000;

app.use(bodyParser.json());

app.use((req, res, next) => {
    console.log(`Request received at: ${req.url}`);
    next();
});

app.use(tutorRoutes);
app.use(petRoutes);

app.listen(port, () => {
    console.log(`Servidor rodando na porta ${port}`);
});
