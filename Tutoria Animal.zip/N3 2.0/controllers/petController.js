const Pet = require('../models/Pet');

module.exports = {
    // adicionar um novo pet
    adicionarPet(req, res) {
        const { nome_pet, genero_pet, altura_cm, cpf_tutor } = req.body;
        console.log('Request body:', req.body); // adicionei log para verificar o corpo da requisição

        Pet.create(nome_pet, genero_pet, altura_cm, cpf_tutor, (error, result) => {
            if (error) {
                console.error('Erro ao adicionar pet:', error); // o log detalhado do erro
                return res.status(500).json({ message: 'Erro ao adicionar pet.', error: error.message });
            }
            res.status(201).json({ message: 'Pet adicionado com sucesso!', pet: result });
        });
    },

    // listar todos os pets
    listarPets(req, res) {
        Pet.findAll((error, pets) => {
            if (error) {
                console.error('Erro ao listar pets:', error);
                return res.status(500).json({ message: 'Erro ao listar pets.', error: error.message });
            }
            res.json(pets);
        });
    },

    // atualizar informações 
    atualizarPet(req, res) {
        const { codigo_pet } = req.params;
        const { nome_pet, genero_pet, altura_cm, cpf_tutor } = req.body;
        Pet.update(codigo_pet, nome_pet, genero_pet, altura_cm, cpf_tutor, (error, result) => {
            if (error) {
                console.error('Erro ao atualizar pet:', error);
                return res.status(500).json({ message: 'Erro ao atualizar pet.', error: error.message });
            }
            if (result.affectedRows > 0) {
                res.json({ message: 'Pet atualizado com sucesso!' });
            } else {
                res.status(404).json({ message: 'Pet não encontrado.' });
            }
        });
    },

    // excluir 
    excluirPet(req, res) {
        const { codigo_pet } = req.params;
        Pet.delete(codigo_pet, (error, result) => {
            if (error) {
                console.error('Erro ao excluir pet:', error);
                return res.status(500).json({ message: 'Erro ao excluir pet.', error: error.message });
            }
            if (result.affectedRows > 0) {
                res.json({ message: 'Pet excluído com sucesso!' });
            } else {
                res.status(404).json({ message: 'Pet não encontrado.' });
            }
        });
    },

    //  buscar pets por tutor (CPF do tutor)
    buscarPetsPorTutor(req, res) {
        const { cpf_tutor } = req.params;
        Pet.findByTutor(cpf_tutor, (error, pets) => {
            if (error) {
                console.error('Erro ao buscar pets por tutor:', error);
                return res.status(500).json({ message: 'Erro ao buscar pets por tutor.', error: error.message });
            }
            res.json(pets);
        });
    },

    //  buscar pets por altura (ID da altura) 1=pequeno 2=medio 3=grande
    buscarPetsPorAltura(req, res) {
        const { altura_id } = req.params;
        Pet.findByAltura(altura_id, (error, pets) => {
            if (error) {
                console.error('Erro ao buscar pets por altura:', error);
                return res.status(500).json({ message: 'Erro ao buscar pets por altura.', error: error.message });
            }
            res.json(pets);
        });
    }
};
