const Tutor = require('../models/Tutor');

module.exports = {
    // adicionar um novo tutor
    adicionarTutor(req, res) {
        const { cpf, nome, email } = req.body;
        Tutor.create(cpf, nome, email, (err, result) => {
            if (err) {
                console.error('Erro ao adicionar tutor:', err);
                res.status(500).json({ message: 'Erro ao adicionar tutor.' });
            } else {
                res.status(201).json({ message: 'Tutor adicionado com sucesso!', tutor: result });
            }
        });
    },

    // listar todos os tutores
    listarTutores(req, res) {
        Tutor.findAll((err, results) => {
            if (err) {
                console.error('Erro ao listar tutores:', err);
                res.status(500).json({ message: 'Erro ao listar tutores.' });
            } else {
                res.json(results);
            }
        });
    },

    // buscar UM tutor por CPF
    buscarTutorPorCpf(req, res) {
        const { cpf } = req.params;
        Tutor.findByCpf(cpf, (err, results) => {
            if (err) {
                console.error('Erro ao buscar tutor por CPF:', err);
                res.status(500).json({ message: 'Erro ao buscar tutor por CPF.' });
            } else if (results.length === 0) {
                res.status(404).json({ message: 'Tutor não encontrado.' });
            } else {
                res.json(results[0]);
            }
        });
    },

    // atualizar os dados do tutor
    atualizarTutor(req, res) {
        const { cpf } = req.params;
        const { nome, email } = req.body;
        Tutor.update(cpf, nome, email, (err, result) => {
            if (err) {
                console.error('Erro ao atualizar tutor:', err);
                res.status(500).json({ message: 'Erro ao atualizar tutor.' });
            } else if (result.affectedRows === 0) {
                res.status(404).json({ message: 'Tutor não encontrado.' });
            } else {
                res.json({ message: 'Tutor atualizado com sucesso!' });
            }
        });
    },

    // excluir um tutor
    excluirTutor(req, res) {
        const { cpf } = req.params;
        Tutor.delete(cpf, (err, result) => {
            if (err) {
                console.error('Erro ao excluir tutor:', err);
                res.status(500).json({ message: 'Erro ao excluir tutor.' });
            } else if (result.affectedRows === 0) {
                res.status(404).json({ message: 'Tutor não encontrado.' });
            } else {
                res.json({ message: 'Tutor excluído com sucesso!' });
            }
        });
    }
};
