const jwt = require('jsonwebtoken');
const secretKey = 'chave_secreta';

// aq eu defino um middleware para verificar se o token JWT está presente e é válido


function verifyToken(req, res, next) {
    const authHeader = req.headers.authorization;
    // verifica se o cabeçalho de autorização está presente na requisição
    if (!authHeader) {
        return res.status(403).json({ message: 'Token não fornecido!' });
    }

    // extrai o token da string "Bearer <token>" no cabeçalho de autorização
    const token = authHeader.split(' ')[1];

    // se o token não estiver presente, retorna um erro
    if (!token) {
        return res.status(403).json({ message: 'Token não fornecido!' });
    }

    // verifica se o token é válido usando a chave secreta
    jwt.verify(token, secretKey, (err, decoded) => {
        if (err) {
            console.error('Erro ao verificar token:', err);
            return res.status(401).json({ message: 'Falha ao autenticar token!' });
        }
        
        // se o token for válido, armazeno os dados decodificados do token na requisição
        req.user = decoded;
        next(); // avança para o próximo middleware ou rota
    });
}

// aq eu defino uma função para gerar um novo token JWT com base nos dados fornecidos
function generateToken(data) {
    return jwt.sign(data, secretKey, { expiresIn: '1h' });
}

module.exports = { verifyToken, generateToken };
